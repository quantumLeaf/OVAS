/* 
 * File:   abstractFeature.cpp
 * Author: zoizoi
 * 
 * Created on 23 January 2011, 17:03
 */

#include "abstractFeature.h"

abstractFeature::abstractFeature() {
}

abstractFeature::abstractFeature(const abstractFeature& orig) {
}

abstractFeature::~abstractFeature() {
}

