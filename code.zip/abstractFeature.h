/* 
 * File:   abstractFeature.h
 * Author: zoizoi
 *
 * Created on 23 January 2011, 17:03
 */

#ifndef ABSTRACTFEATURE_H
#define	ABSTRACTFEATURE_H

class abstractFeature {
public:
    abstractFeature();
    abstractFeature(const abstractFeature& orig);
    virtual ~abstractFeature();
private:

};

#endif	/* ABSTRACTFEATURE_H */

